<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$malopcu = $_GET['malopcu'];

$txtMaLop = $_POST['txtMaLop'];
$txtTenLop = $_POST['txtTenLop'];

//Cap nhat vao CSDL
$sql = "UPDATE lop SET MaLop = '" . $txtMaLop . "', TenLop = '". $txtTenLop. "' WHERE MaLop = '" . $malopcu . "'";

if (mysqli_query($conn, $sql)) {
	header('Location: dslop.php?status=update_success');
} else {
	header('Location: dslop.php?status=update_fail');
}
?>