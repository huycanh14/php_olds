<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$malop = $_GET['malop'];

//Cap nhat vao CSDL
$sql = "DELETE FROM lop WHERE malop = '" . $malop . "'";
if (mysqli_query($conn, $sql)) {
	header('Location: dslop.php?status=del_success');
} else {
	header('Location: dslop.php?status=del_fail');
}


?>