<html>
<head>
    <title>Danh sach lop</title>
</head>
<body>

<p>
	<a href="themlop.php">Thêm lớp</a>
</p>

<?php
$status = isset($_GET["status"]) ? $_GET["status"] : "";
if ($status == 'add_success') {
	echo '<div style="color: green">Thêm thành công!</div>';
} else if ($status == 'add_fail') {
	echo '<div style="color: red">Thêm thất bại!</div>';
} else if ($status == 'del_success') {
	echo '<div style="color: green">Xóa thành công!</div>';
} else if ($status == 'del_fail') {
	echo '<div style="color: red">Xóa thất bại!</div>';
} else if ($status == 'update_success') {
	echo '<div style="color: green">Cập nhật thành công!</div>';
} else if ($status == 'update_fail') {
	echo '<div style="color: red">Cập nhật thất bại!</div>';
}


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = 'SELECT * FROM Lop';
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	echo '<table border="1">';	
	echo '<tr>';
	echo '<th>Mã lớp</th>';
	echo '<th>Tên lớp</th>';
	echo '<th>Thao tác</th>';
	echo '</tr>';

    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['MaLop']. '</td>';
        echo '<td>' . $row["TenLop"]. '</td>';
        echo '<td style="text-align: center"><a href="sualop.php?malop='. $row['MaLop']. '">Sửa</a> &nbsp; <a href="xoalop.php?malop='. $row['MaLop']. '">Xóa</a></td>';
        echo '</tr>';
    }

    echo '</table>';
}

mysqli_close($conn);
?>

</body>
</html>