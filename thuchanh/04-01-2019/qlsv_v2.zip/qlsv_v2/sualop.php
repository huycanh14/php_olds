<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$malopcu = $_GET['malop'];
$malop = $_GET['malop'];
$tenlop = '';

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT * FROM Lop WHERE malop = '" . $malop . "'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);
	$malop = $row["MaLop"];
	$tenlop = $row["TenLop"];
}
?>

<html>
<head>
	<title>Sua lop</title>
</head>
<body>
<form method="post" action="sualop_processing.php?malopcu=<?php echo $malopcu; ?>">
<table border="0" width="100%" align="center"> 
<tr>
	<td align="center">Sửa lớp</td>
</tr>
<tr>
	<td>
	  <table border="0" width="50%" align="center">
		<tr>
		  <td width="100">Mã lớp: </td>
		  <td>
		  	<input type="text" name="txtMaLop" value="<?php echo $malop; ?>"></td>
		</tr>
		<tr>
		  <td>Tên lớp: </td>
		  <td><input type="text" name="txtTenLop" value="<?php echo $tenlop; ?>"></td>
		</tr>
		<tr>
		  <td align="center" colspan="2"><input type="submit" name="btnUpdate" value="Sửa">&nbsp;<input type="button" name="btnCancel" value="Bỏ" onclick="history.back(1)"></td>
		</tr>
	  </table>
	</td>
</tr>
</table>
</form>
</body>
</html>